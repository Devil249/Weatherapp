package kamal.aishwarya.weather.model

data class Hour(
    val time: String,
    val icon: String,
    val temperature: String,
)
