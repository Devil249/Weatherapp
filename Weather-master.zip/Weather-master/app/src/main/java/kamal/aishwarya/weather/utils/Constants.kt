package kamal.aishwarya.weather.utils

const val BASE_URL = "https://api.weatherapi.com/v1/"
const val DEFAULT_WEATHER_DESTINATION = "Munich"
const val NUMBER_OF_DAYS = 10