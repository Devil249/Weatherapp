package kamal.aishwarya.weather.ui.weather

enum class SearchWidgetState {
    OPENED,
    CLOSED
}